package pl.pollub.footballapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.pollub.footballapp.model.User;
import pl.pollub.footballapp.repository.UserRepository;
import pl.pollub.footballapp.service.UserService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    // Endpoint dostępny tylko dla administratora
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/add-moderator")
    public ResponseEntity<?> addModerator(@RequestBody User moderatorRequest) {
        if (userRepository.existsByEmail(moderatorRequest.getEmail())) {
            return ResponseEntity.badRequest().body("Email already in use");
        }

        User moderator = new User();
        moderator.setEmail(moderatorRequest.getEmail());
        moderator.setPassword(userService.encodePassword(moderatorRequest.getPassword()));
        moderator.setRole(User.Role.MODERATOR);

        userRepository.save(moderator);
        return ResponseEntity.ok("Moderator added successfully");
    }
}
