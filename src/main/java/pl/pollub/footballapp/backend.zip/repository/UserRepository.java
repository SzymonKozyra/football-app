package pl.pollub.footballapp.repository;

import pl.pollub.footballapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    // Możesz dodać tutaj inne metody wyszukiwania, np. wyszukiwanie po emailu
    Optional<User> findByEmail(String email);

    // Sprawdź, czy użytkownik istnieje po emailu
    boolean existsByEmail(String email);
}