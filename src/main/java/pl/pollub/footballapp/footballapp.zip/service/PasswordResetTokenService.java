package pl.pollub.footballapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pl.pollub.footballapp.model.PasswordResetToken;
import pl.pollub.footballapp.model.User;
import pl.pollub.footballapp.repository.PasswordResetTokenRepository;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class PasswordResetTokenService {

    @Autowired
    private PasswordResetTokenRepository tokenRepository;

    public String createToken(User user) {
        String token = UUID.randomUUID().toString();
        PasswordResetToken passwordResetToken = new PasswordResetToken(token, user, LocalDateTime.now().plusHours(1));
        tokenRepository.save(passwordResetToken);
        return token;
    }

    public boolean validateToken(String token) {
        Optional<PasswordResetToken> passwordResetToken = tokenRepository.findByToken(token);

        // Sprawdzenie, czy token istnieje i czy nie wygasł
        return passwordResetToken.isPresent() &&
                passwordResetToken.get().getExpiryDate().isAfter(LocalDateTime.now());
    }

    // Funkcja do pobierania użytkownika na podstawie tokenu
    public User getUserByToken(String token) {
        // Znajduje token w bazie danych
        Optional<PasswordResetToken> passwordResetToken = tokenRepository.findByToken(token);

        // Jeśli token istnieje i nie wygasł, zwróć użytkownika powiązanego z tokenem
        if (passwordResetToken.isPresent() && passwordResetToken.get().getExpiryDate().isAfter(LocalDateTime.now())) {
            return passwordResetToken.get().getUser();
        }

        // Jeśli token nie istnieje lub wygasł, zwróć null (możesz rzucić wyjątek zamiast tego)
        return null;
    }
}
