package pl.pollub.footballapp.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import pl.pollub.footballapp.model.User;
import pl.pollub.footballapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.pollub.footballapp.service.UserService;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import pl.pollub.footballapp.util.JwtUtil;


@RestController //  Definiuje główny URL dla tego kontrolera. Wszystkie endpointy zdefiniowane w tej klasie będą miały prefiks /api/auth.
@RequestMapping("/api/auth") // Definiuje główny URL dla tego kontrolera. Wszystkie endpointy zdefiniowane w tej klasie będą miały prefiks /api/auth.
@CrossOrigin(origins = "http://localhost:3000")  // Dodaj tę linię
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        // Sprawdź, czy istnieje już użytkownik o podanym adresie email
        if (userRepository.existsByEmail(user.getEmail())) {
            return ResponseEntity.badRequest().body("Email already in use");
        }

        // Ustawienie domyślnej roli USER
        user.setRole(User.Role.ROLE_USER);

        userService.registerUser(user); // Zarejestruj użytkownika (hashowanie hasła wewnątrz)
        return ResponseEntity.ok("User registered successfully");
    }

    @Autowired
    private UserDetailsService userDetailsService;  // Inject UserDetailsService

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User loginRequest) {
        // Find the user by email
        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());

        // If the user does not exist or the password is incorrect, return an error
        if (userOptional.isEmpty() || !userService.checkPassword(loginRequest.getPassword(), userOptional.get().getPassword())) {
            return ResponseEntity.status(401).body("Invalid email or password");
        }

        // Get the authenticated user
        User user = userOptional.get();

        // Load UserDetails from UserDetailsService
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());

        // Generate the JWT token using the UserDetails
        String jwtToken = jwtUtil.generateToken(userDetails);

        // Return the response with the email, role, and JWT token
        Map<String, String> response = new HashMap<>();
        response.put("email", user.getEmail());
        response.put("role", user.getRole().name());
        response.put("token", jwtToken);  // Include the JWT token in the response

        // Successful login
        return ResponseEntity.ok(response);
    }

//    @PostMapping("/login")
//    public ResponseEntity<?> loginUser(@RequestBody User loginRequest) {
//        // Znajdź użytkownika po emailu
//        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());
//
//        // Jeśli użytkownik nie istnieje lub hasło jest nieprawidłowe, zwróć błąd
//        if (userOptional.isEmpty() || !userService.checkPassword(loginRequest.getPassword(), userOptional.get().getPassword())) {
//            return ResponseEntity.status(401).body("Invalid email or password");
//        }
//
//        // Pobierz zalogowanego użytkownika
//        User user = userOptional.get();
//
//        // Generuj JWT
//        String jwtToken = jwtUtil.generateToken(user.getEmail());
//
//        // Zwróć odpowiedź z emailem i rolą
//        Map<String, String> response = new HashMap<>();
//        response.put("email", user.getEmail());
//        response.put("role", user.getRole().name());
//        response.put("token", jwtToken);
//
//        // Zalogowano poprawnie
//        return ResponseEntity.ok(response);
//    }


    @DeleteMapping("/delete-account")
    public ResponseEntity<?> deleteAccount() {
        // Pobierz obecnie zalogowanego użytkownika
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String currentUsername;

        if (principal instanceof UserDetails) {
            currentUsername = ((UserDetails) principal).getUsername();
        } else {
            return ResponseEntity.status(404).body("User not found");
        }

        // Znajdź użytkownika po emailu
        Optional<User> userOptional = userRepository.findByEmail(currentUsername);

        if (userOptional.isEmpty()) {
            return ResponseEntity.status(404).body("User not found");
        }

        // Usuń konto użytkownika
        userRepository.delete(userOptional.get());

        // Wylogowanie użytkownika po usunięciu konta
        SecurityContextHolder.clearContext();

        return ResponseEntity.ok("Account deleted successfully");
    }



}